package com.example.database_work

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
