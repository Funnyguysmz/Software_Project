import 'package:flutter/material.dart';

// 定义其他页面
class OtherPage extends StatelessWidget {
  const OtherPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('This is the other page'),
    );
  }
}
